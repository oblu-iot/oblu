from connectivity_modules.connectivity import Connectivity
from connectivity_modules.usb_conn import UsbConnectivity

if __name__ == '__main__':
    ble_connectivity = UsbConnectivity()
    print 'Subclass:', issubclass(UsbConnectivity, Connectivity)
    print 'Instance:', isinstance(UsbConnectivity(), Connectivity)