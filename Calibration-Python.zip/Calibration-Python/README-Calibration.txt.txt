﻿
System requirement
	•	Windows 7 or newer  
	•	Ubuntu 16.04 or Linux 
	•	Python 2.7.*

	Before executing the caliberation script, make sure that you have setup python as per document https://www.inertialelements.com/oblu/resources/python-setup-guidelines.pdf

	If you want execute scripts for BLE, then you must execute the script in Linux.


How to execute the calibrations scripts for different connections type:

	In the top of main.py scripts, there is 3 parameters out_rate, conn_params and conn_type.

	1)  USB connection

		out_rate = float(1000)		    # set data rate transmission,e.g. 1000, 500, 250	
		conn_params = ('/dev/ttyACM0', 115200)# set port name and baud rate in tuple 
		conn_type = 'usb'		    # For usb connectivity , you must set ‘usb’		

		 To find the serial port name , refer the link https://www.inertialelements.com/oblu/resources/how-to-find-serial-port.pdf

	2) WiFi connection
		out_rate = float(125)		    # set data rate transmission,e.g. 250, 125, 62.5		
		conn_params = ('192.168.43.201', 9876)# set IP address of device and port number 
		conn_type = 'wifi'		    # For WiFi connectivity , you must set ‘wifi’ 


		Use NMAP tool to scan your network and search device with mac address. Check your product details for mac address.
			 

	3) BLE connection (LINUX)
		out_rate = float(125)		# set data rate transmission,e.g.125, 62.5, 31.25
		conn_params = ('00:A0:50:E4:AC:20',) # set device’s MAC address in tuple
		conn_type = 'ble'		# For BLE connectivity , you must set ‘ble’

		 To check the list of nearby Bluetooth devices. Enter below commands.
			> sudo hcitool lescan
		

Runninig Calibration Script:
	 Execute the calibration script, run the main.py
	 
	 > python main.py
